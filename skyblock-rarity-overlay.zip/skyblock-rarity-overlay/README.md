# SkyBlock Rarity Overlay (Minecraft 26.2, Fabric, client-side)

Smooth circular (or square) rarity outlines around item icons in inventory screens and the hotbar.
Detects the nine SkyBlock rarities from the item's tooltip lore. Every rarity has its own color, picker and reset button.

## ⚠ Verification status (read first)
**This project has NOT been compiled or run.** It was written in a sandbox with Java 21 only, no Gradle and no network,
so no JAR is included. Only `Rarity` and `ColorUtil` (hex parsing, HSV round-trip, defaults) were executed and passed.
Everything else is written against 26.2 APIs reported by public 26.2 projects, but **never checked against the real jars**.
Expect to fix a few signatures on the first build; each risky spot is isolated and listed below.

| Assumption (26.2) | Where | If it fails to compile/run |
|---|---|---|
| `GuiGraphicsExtractor`, `AbstractContainerScreen#extractSlot(GuiGraphicsExtractor, Slot, int, int)` | mixin | check name with `javap -p` on the Loom-cached Minecraft jar |
| `Screen#extractRenderState`, `GuiGraphicsExtractor#fill/text/centeredText/item/blit` | ConfigScreen, OverlayRenderer | adjust names/overloads |
| `blit(RenderPipelines.GUI_TEXTURED, id, x, y, u, v, w, h, srcW, srcH, texW, texH)` | OverlayRenderer | use the matching overload |
| `NativeImage#setPixel` = ARGB, `new DynamicTexture(Supplier<String>, NativeImage)`, `TextureManager#register/release` | OverlayTextures | red/blue swapped → use `setPixelABGR` |
| `MouseButtonEvent` mouse overrides | ConfigScreen | match `Screen` signatures |
| `HudElementRegistry.attachElementAfter`, `KeyMappingHelper`, `KeyMapping.Category.register` | RarityOverlayMod | check Fabric API 0.150.1+26.2 |
| `setScreen` was renamed/moved in 26.2 | `Compat` (reflection) | add the right method name |
| Loom `1.15.5`, loader `0.19.3`, Fabric API `0.150.1+26.2`, Java 25 | gradle.properties | bump to latest for 26.2 |

Never tested: real Hypixel items, in-game visuals, persistence across restarts, performance. The manual test guide below is how you verify them.

## Install / build
1. Install **JDK 25**. `gradlew` / `gradlew.bat` are included; on first run they download `gradle-wrapper.jar` themselves (needs internet), then Gradle 9.3.0.
2. `./gradlew build` → `build/libs/skyblock-rarity-overlay-1.0.0.jar`.
3. Put the jar in `mods/` with Fabric Loader ≥ 0.19.3 and Fabric API for 26.2. Client only; nothing is needed on the server.

## Use
Press **O** in-game (rebindable: "SkyBlock Rarity Overlay") to open settings. Config file: `config/skyblock-rarity-overlay.json`.
Screen needs about 420×240 GUI units (lower the GUI scale on small windows).

* **General**: Overlay on/off, Inventory on/off, Hotbar on/off.
* **Appearance**: Circular/Square, Thickness (0.5–3), Opacity, Inset (0–3, shrinks the outline; max size 18 never overlaps neighbours), Tint (faint interior fill).
* **Colors**: click a rarity name to select it, then use the SV square + hue bar, HEX box (`#A855F7`, `A855F7`, `#A5F`) or R/G/B boxes. Invalid input turns red and is ignored. Each row's **Reset** restores only that rarity; **Reset All Colors to Defaults** restores all nine and leaves shape/thickness/opacity/inset alone; **Reset All Settings** (with confirmation) restores everything.
* **Preview**: all nine rarities at true size, drawn by the same renderer as the real GUI; real slots update at the same time.

## How it works
* **Detection** (`RarityDetector`): walks the last 6 lore `Component`s, collects only BOLD, non-obfuscated text (so recombobulator glyphs and normal lore like "Common knowledge" are ignored) and matches the leading token. `VERY SPECIAL` and `SPECIAL` cannot be confused. Results are cached per `ItemLore` instance, so a tooltip is parsed once and re-parsed only when the server sends changed item data.
* **Rendering** (`OverlayTextures`/`OverlayRenderer`): the outline is baked into a texture sized exactly diameter × GUI scale pixels with analytic anti-aliasing (1 texel = 1 screen pixel → smooth edges, uniform thickness, any GUI scale). Rebuilt only when settings, GUI scale or that rarity's color change. Square mode uses the same pipeline with a Chebyshev distance.
* **Scope**: one mixin on `AbstractContainerScreen#extractSlot` (inventory, chests, etc.; drawn under the item) and a Fabric HUD element after the vanilla hotbar (selected slot included). Held items, dropped items, item frames and world rendering are never touched.

## Known limitations
* The interior tint is only drawn in container screens. On the HUD the outline is drawn after the vanilla hotbar, so a tint would dim the item.
* Rarity comes from the item's lore (`DataComponents.LORE`), the data the tooltip is built from, not from a full `getTooltipLines` call.
* Items whose rarity line is not within the last 6 lore lines, or not bold, show no outline.
* Mod Menu integration is not included; use the keybind.

## Manual test guide
1. Launch with the mod; confirm `config/skyblock-rarity-overlay.json` appears with the nine default hex colors.
2. Hypixel SkyBlock: view items of each rarity in the inventory and hotbar; check COMMON…VERY SPECIAL, a recombobulated item, and a pet. VERY SPECIAL vs SPECIAL must differ in the log/preview when you give them different colors.
3. Open settings (O): switch Circular/Square, drag Thickness/Opacity/Inset/Tint; preview and the real inventory change instantly. Try GUI scales 1–4 and check the circle stays smooth and centered.
4. Customize all nine colors (picker, HEX, RGB, invalid input like `#GG0000`). Reset one rarity → only it reverts. Change several again → **Reset All Colors to Defaults** → all nine equal the defaults, shape/thickness/opacity/inset unchanged.
5. Restart Minecraft: custom colors and reset colors persist. Delete or corrupt the JSON: defaults load, no crash (bad file is renamed `.invalid`).
6. Confirm no outline on held items, dropped items, item frames, empty slots, or items without a rarity line.
7. Open a large chest / use the hotbar with F3 frame times to confirm no measurable cost.
