@echo off
rem Self-bootstrapping Gradle wrapper launcher (downloads gradle-wrapper.jar on first run).
setlocal
set "APP_HOME=%~dp0"
set "JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "URL=https://raw.githubusercontent.com/gradle/gradle/v9.3.0/gradle/wrapper/gradle-wrapper.jar"

if not exist "%JAR%" (
  echo Downloading gradle-wrapper.jar ...
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%JAR%'"
  if errorlevel 1 ( echo Download failed. Run: gradle wrapper --gradle-version 9.3.0 & exit /b 1 )
)

if defined JAVA_HOME ( set "JAVACMD=%JAVA_HOME%\bin\java.exe" ) else ( set "JAVACMD=java" )
"%JAVACMD%" -Dorg.gradle.appname=gradlew -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
