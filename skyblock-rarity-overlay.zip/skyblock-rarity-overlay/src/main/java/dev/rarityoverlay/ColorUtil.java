package dev.rarityoverlay;

/** Hex parsing/formatting and HSV conversion. No AWT dependency. */
public final class ColorUtil {
    private ColorUtil() {}

    /** Accepts "#RRGGBB", "RRGGBB", "#RGB", "RGB". Returns 0xRRGGBB, or -1 if invalid. */
    public static int parseHex(String s) {
        if (s == null) return -1;
        s = s.trim();
        if (s.startsWith("#")) s = s.substring(1);
        try {
            if (s.length() == 3) {
                int r = Integer.parseInt(s.substring(0, 1), 16);
                int g = Integer.parseInt(s.substring(1, 2), 16);
                int b = Integer.parseInt(s.substring(2, 3), 16);
                return ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
            }
            if (s.length() == 6) {
                // parseInt would accept a leading '+'/'-', so check characters explicitly.
                for (int i = 0; i < 6; i++) if (Character.digit(s.charAt(i), 16) < 0) return -1;
                return Integer.parseInt(s, 16);
            }
        } catch (NumberFormatException ignored) { }
        return -1;
    }

    public static String toHex(int rgb) {
        return String.format("#%06X", rgb & 0xFFFFFF);
    }

    /** Returns 0..255 or -1 if not a valid integer in range. */
    public static int parseChannel(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            return (v >= 0 && v <= 255) ? v : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static int hsvToRgb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s;
        float x = c * (1 - Math.abs((h * 6) % 2 - 1));
        float m = v - c;
        float r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    /** Returns {h, s, v}, each 0..1. */
    public static float[] rgbToHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float d = max - min, h;
        if (d == 0) h = 0;
        else if (max == r) h = (((g - b) / d) % 6) / 6f;
        else if (max == g) h = (((b - r) / d) + 2) / 6f;
        else h = (((r - g) / d) + 4) / 6f;
        if (h < 0) h += 1;
        return new float[] { h, max == 0 ? 0 : d / max, max };
    }
}
