package dev.rarityoverlay;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Method;

/**
 * Opens a screen. Between 26.1 and 26.2 Minecraft#setScreen was renamed/moved (setScreenAndShow / Gui#setScreen
 * were both reported), so we look it up once by name instead of hard-binding to one of them.
 */
public final class Compat {
    private Compat() {}
    private static Method method;
    private static Object target;

    public static void setScreen(Screen screen) {
        Minecraft mc = Minecraft.getInstance();
        try {
            if (method == null) resolve(mc);
            method.invoke(target, screen);
        } catch (ReflectiveOperationException | NullPointerException e) {
            throw new IllegalStateException("Cannot open screen: no setScreen method found (see Compat.java)", e);
        }
    }

    private static void resolve(Minecraft mc) {
        Object[] targets = { mc, mc.gui };
        String[] names = { "setScreenAndShow", "setScreen" };
        for (Object t : targets) {
            if (t == null) continue;
            for (String n : names) {
                try {
                    method = t.getClass().getMethod(n, Screen.class);
                    target = t;
                    return;
                } catch (NoSuchMethodException ignored) { }
            }
        }
    }
}
