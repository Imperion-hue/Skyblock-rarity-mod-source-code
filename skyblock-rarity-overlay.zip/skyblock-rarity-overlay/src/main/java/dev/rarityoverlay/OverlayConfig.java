package dev.rarityoverlay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Persistent settings. Every rarity color is stored independently.
 * Mutate fields, then call {@link #touch()} (invalidates cached textures) and {@link #save()}.
 */
public final class OverlayConfig {
    public enum Shape { CIRCLE, SQUARE }

    private static final Logger LOG = LoggerFactory.getLogger("rarityoverlay");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("skyblock-rarity-overlay.json");
    private static OverlayConfig instance;

    // Defaults (used by resetAll and as first-launch values)
    public static final float DEF_OPACITY = 0.85f;
    public static final float DEF_INSET = 0f;

    public boolean enabled = true;
    public boolean inventory = true;
    public boolean hotbar = true;
    public Shape shape = Shape.CIRCLE;
    /** Opacity of the filled shape (0.1 .. 1.0). */
    public float opacity = DEF_OPACITY;
    /** Shrinks the shape by this many GUI units per side (0.00 .. 6.00, any value). Full size = 16 units (the slot interior). */
    public float inset = DEF_INSET;

    private final int[] rgb = new int[Rarity.VALUES.length];

    /** Bumped on every change; OverlayTextures compares it to know when to rebuild. */
    public int revision = 1;

    private OverlayConfig() { resetAllColors(); }

    public static OverlayConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    public int getColor(Rarity r) { return rgb[r.ordinal()]; }
    public void setColor(Rarity r, int value) { rgb[r.ordinal()] = value & 0xFFFFFF; touch(); }
    public void resetColor(Rarity r) { rgb[r.ordinal()] = r.defaultRgb; touch(); }

    public void resetAllColors() {
        for (Rarity r : Rarity.VALUES) rgb[r.ordinal()] = r.defaultRgb;
        touch();
    }

    /** Resets everything: colors AND appearance/toggles. */
    public void resetAll() {
        enabled = inventory = hotbar = true;
        shape = Shape.CIRCLE;
        opacity = DEF_OPACITY; inset = DEF_INSET;
        resetAllColors();
    }

    public void touch() { revision++; }

    // ---------------------------------------------------------------- persistence

    private static OverlayConfig load() {
        OverlayConfig c = new OverlayConfig();
        if (!Files.isRegularFile(PATH)) { c.save(); return c; }   // first launch: write defaults
        try {
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            c.enabled = bool(o, "enabled", c.enabled);
            c.inventory = bool(o, "inventory", c.inventory);
            c.hotbar = bool(o, "hotbar", c.hotbar);
            try { c.shape = Shape.valueOf(o.get("shape").getAsString().toUpperCase()); } catch (Exception ignored) { }
            c.opacity = clamp(num(o, "opacity", c.opacity), 0.1f, 1f);
            c.inset = clamp(num(o, "inset", c.inset), 0f, 6f);
            if (o.has("colors") && o.get("colors").isJsonObject()) {
                JsonObject colors = o.getAsJsonObject("colors");
                for (Rarity r : Rarity.VALUES) {
                    JsonElement e = colors.get(r.name());
                    int v = (e != null && e.isJsonPrimitive()) ? ColorUtil.parseHex(e.getAsString()) : -1;
                    if (v >= 0) c.rgb[r.ordinal()] = v;      // invalid/missing -> keep that rarity's default only
                }
            }
        } catch (Exception ex) {
            LOG.warn("Config unreadable, using defaults (bad file kept as .invalid)", ex);
            try { Files.move(PATH, PATH.resolveSibling(PATH.getFileName() + ".invalid"), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) { }
            c = new OverlayConfig();
        }
        return c;
    }

    public void save() {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", enabled);
        o.addProperty("inventory", inventory);
        o.addProperty("hotbar", hotbar);
        o.addProperty("shape", shape.name());
        o.addProperty("opacity", opacity);
        o.addProperty("inset", inset);
        JsonObject colors = new JsonObject();
        for (Rarity r : Rarity.VALUES) colors.addProperty(r.name(), ColorUtil.toHex(rgb[r.ordinal()]));
        o.add("colors", colors);
        try {
            Path tmp = PATH.resolveSibling(PATH.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(o));
            Files.move(tmp, PATH, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            LOG.error("Could not save config", e);
        }
    }

    private static boolean bool(JsonObject o, String k, boolean d) {
        try { return o.get(k).getAsBoolean(); } catch (Exception e) { return d; }
    }
    private static float num(JsonObject o, String k, float d) {
        try { float v = o.get(k).getAsFloat(); return Float.isFinite(v) ? v : d; } catch (Exception e) { return d; }
    }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
