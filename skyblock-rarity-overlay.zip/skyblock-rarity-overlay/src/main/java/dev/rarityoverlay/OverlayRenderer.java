package dev.rarityoverlay;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Draws the filled shape BEHIND the item. Inventory slots and hotbar slots use the exact same draw(), so they look identical.
 * Only called from container-slot / hotbar-slot hooks, never from world item rendering.
 */
public final class OverlayRenderer {
    private OverlayRenderer() {}

    /** Set by the Hud mixin each time it runs; lets the fallback HUD element know the mixin is working. */
    private static long hotbarHookMs;

    /** Container/inventory screens (called at HEAD of extractSlot). */
    public static void drawSlot(GuiGraphicsExtractor g, Slot slot) {
        OverlayConfig cfg = OverlayConfig.get();
        if (!cfg.enabled || !cfg.inventory) return;
        draw(g, slot.x, slot.y, slot.getItem(), false);
    }

    /** Hotbar slot (called at HEAD of Hud#extractSlot, i.e. before the vanilla item is drawn). x,y = item origin. */
    public static void drawHotbarSlot(GuiGraphicsExtractor g, int x, int y, ItemStack stack) {
        hotbarHookMs = System.currentTimeMillis();
        OverlayConfig cfg = OverlayConfig.get();
        if (!cfg.enabled || !cfg.hotbar) return;
        draw(g, x, y, stack, true);
    }

    /**
     * Fallback only: if the Hud mixin never ran (target not found), draw from a HUD element after the hotbar.
     * In that mode the shape ends up over the item, so it is a degraded but still working display.
     */
    public static void drawHotbarFallback(GuiGraphicsExtractor g) {
        if (System.currentTimeMillis() - hotbarHookMs < 1000) return;
        OverlayConfig cfg = OverlayConfig.get();
        if (!cfg.enabled || !cfg.hotbar) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || p.isSpectator()) return;
        int baseX = mc.getWindow().getGuiScaledWidth() / 2 - 90 + 2;
        int y = mc.getWindow().getGuiScaledHeight() - 16 - 3;
        for (int i = 0; i < 9; i++) draw(g, baseX + i * 20, y, p.getInventory().getItem(i), true);
    }

    public static void draw(GuiGraphicsExtractor g, int x, int y, ItemStack stack, boolean hotbar) {
        if (stack.isEmpty()) return;
        Rarity r = RarityDetector.detect(stack);
        if (r != null) draw(g, x, y, r, hotbar);
    }

    /**
     * @param x,y    top-left of the 16x16 item icon (the slot interior in inventory and hotbar alike).
     * @param hotbar unused: both use the same shape. The texture is always a 16x16-unit canvas with the shape centered
     *               inside it, so it is perfectly centered on the item and can never leave the slot interior.
     */
    public static void draw(GuiGraphicsExtractor g, int x, int y, Rarity r, boolean hotbar) {
        Identifier tex = OverlayTextures.get(r);
        if (tex == null) return;
        int px = 16 * OverlayTextures.guiScale();
        g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, 0f, 0f, 16, 16, px, px, px, px);
    }
}
