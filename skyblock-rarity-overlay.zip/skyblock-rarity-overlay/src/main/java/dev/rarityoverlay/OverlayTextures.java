package dev.rarityoverlay;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Bakes a solid filled disc (or square) in the rarity color into a small texture, one per rarity.
 *
 * The texture is exactly (diameter * guiScale) pixels, so 1 texel == 1 physical screen pixel. Each texel gets analytic
 * anti-aliased coverage (1px soft edge), which keeps the circle smooth at every GUI scale.
 * Rebuilt lazily only when settings, GUI scale or that rarity's color change. Replaced textures are closed >1s later
 * so a texture queued earlier in the same frame is never freed under it.
 */
public final class OverlayTextures {
    private OverlayTextures() {}

    private static final class Entry {
        Identifier id; int revision = -1, scale = -1, rgb = -1;
    }
    private record Retired(Identifier id, long at) {}

    private static final Entry[][] ENTRIES = new Entry[Rarity.VALUES.length][2];
    private static final List<Retired> RETIRED = new ArrayList<>();
    private static int counter;

    public static Identifier get(Rarity r) {
        OverlayConfig cfg = OverlayConfig.get();
        int scale = guiScale();
        int rgb = cfg.getColor(r);
        Entry e = ENTRIES[r.ordinal()][0];
        if (e == null) e = ENTRIES[r.ordinal()][0] = new Entry();
        if (e.id == null || e.revision != cfg.revision || e.scale != scale || e.rgb != rgb) {
            Identifier old = e.id;
            try {
                e.id = build(r, cfg, scale, rgb);
            } catch (RuntimeException ex) {
                e.id = null;                       // draw nothing rather than crash
                e.revision = -1;
                return null;
            }
            e.revision = cfg.revision; e.scale = scale; e.rgb = rgb;
            if (old != null) RETIRED.add(new Retired(old, System.currentTimeMillis()));
        }
        purge();
        return e.id;
    }

    public static int guiScale() {
        return Math.max(1, (int) Minecraft.getInstance().getWindow().getGuiScale());
    }

    private static Identifier build(Rarity r, OverlayConfig cfg, int scale, int rgb) {
        int w = 16 * scale;                   // fixed 16-unit canvas (the slot interior); texels == physical pixels
        float half = w / 2f;
        float radius = (8f - cfg.inset) * scale;   // any fractional size; the canvas stays integer-aligned, so centering is exact
        boolean circle = cfg.shape == OverlayConfig.Shape.CIRCLE;

        NativeImage img = new NativeImage(w, w, false);
        for (int y = 0; y < w; y++) {
            float py = y + 0.5f - half;
            for (int x = 0; x < w; x++) {
                float px = x + 0.5f - half;
                // circle: Euclidean distance; square: Chebyshev distance (sharp square corners)
                float d = circle ? (float) Math.sqrt(px * px + py * py) : Math.max(Math.abs(px), Math.abs(py));
                float cov = clamp01(radius - d + 0.5f);      // 1px anti-aliased edge
                int alpha = Math.round(cov * cfg.opacity * 255f);
                img.setPixel(x, y, (alpha << 24) | rgb);   // ARGB
            }
        }
        Identifier id = Identifier.fromNamespaceAndPath(RarityOverlayMod.MOD_ID, "gen/" + r.name().toLowerCase() + "_" + (counter++));
        DynamicTexture tex = new DynamicTexture(() -> "rarityoverlay " + id, img);
        Minecraft.getInstance().getTextureManager().register(id, tex);
        return id;
    }

    private static void purge() {
        if (RETIRED.isEmpty()) return;
        long now = System.currentTimeMillis();
        TextureManager tm = Minecraft.getInstance().getTextureManager();
        RETIRED.removeIf(rt -> {
            if (now - rt.at() < 1000) return false;
            tm.release(rt.id());
            return true;
        });
    }

    private static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1); }
}
