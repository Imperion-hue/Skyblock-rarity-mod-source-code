package dev.rarityoverlay;

/** The nine SkyBlock rarities, their tooltip tokens and default colors. Each has its own config entry. */
public enum Rarity {
    COMMON("COMMON", "Common", 0xFFFFFF),
    UNCOMMON("UNCOMMON", "Uncommon", 0x00FF00),
    RARE("RARE", "Rare", 0x5555FF),
    EPIC("EPIC", "Epic", 0xAA00AA),
    LEGENDARY("LEGENDARY", "Legendary", 0xFFAA00),
    MYTHIC("MYTHIC", "Mythic", 0xFF55FF),
    DIVINE("DIVINE", "Divine", 0x55FFFF),
    SPECIAL("SPECIAL", "Special", 0xFF5555),
    VERY_SPECIAL("VERY SPECIAL", "Very Special", 0xFF5555);

    public static final Rarity[] VALUES = values();

    /** Text as it appears in the tooltip's rarity line. */
    public final String token;
    public final String display;
    public final int defaultRgb;

    Rarity(String token, String display, int defaultRgb) {
        this.token = token;
        this.display = display;
        this.defaultRgb = defaultRgb;
    }
}
