package dev.rarityoverlay;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Reads the SkyBlock rarity from the item's tooltip lore (structured Components, not raw strings).
 *
 * SkyBlock puts the rarity on one of the last lore lines in BOLD, e.g. "LEGENDARY SWORD" or
 * "VERY SPECIAL". Recombobulated items add obfuscated filler glyphs around it, which we skip.
 * Only BOLD, non-obfuscated segments are considered, so ordinary lore / enchant text such as
 * "Common knowledge" is never mistaken for a rarity.
 *
 * Results are cached per ItemLore instance (identity). When the server sends changed item data a new
 * ItemLore object appears, so the cache invalidates itself without any explicit hook.
 */
public final class RarityDetector {
    private RarityDetector() {}

    private static final int SCAN_LAST_LINES = 6;
    private static final Map<ItemLore, Rarity> CACHE = new IdentityHashMap<>(); // render thread only

    /** @return rarity, or null if the stack has no detectable rarity. */
    public static Rarity detect(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        ItemLore lore = stack.get(DataComponents.LORE);
        if (lore == null) return null;
        if (CACHE.containsKey(lore)) return CACHE.get(lore);
        Rarity r;
        try {
            r = scan(lore.lines());
        } catch (RuntimeException e) {   // malformed tooltip data must never crash rendering
            r = null;
        }
        if (CACHE.size() > 4096) CACHE.clear();
        CACHE.put(lore, r);
        return r;
    }

    public static void clearCache() { CACHE.clear(); }

    private static Rarity scan(List<Component> lines) {
        int stop = Math.max(0, lines.size() - SCAN_LAST_LINES);
        for (int i = lines.size() - 1; i >= stop; i--) {
            Rarity r = match(lines.get(i));
            if (r != null) return r;
        }
        return null;
    }

    private static Rarity match(Component line) {
        StringBuilder sb = new StringBuilder(32);
        line.visit((Style style, String text) -> {
            if (style.isBold() && !style.isObfuscated()) sb.append(text);
            return Optional.empty();   // keep visiting
        }, Style.EMPTY);
        String s = sb.toString().strip();
        if (s.isEmpty()) return null;
        for (Rarity r : Rarity.VALUES) {
            // "VERY SPECIAL" does not start with "SPECIAL", so the two can never be confused.
            if (s.startsWith(r.token) && (s.length() == r.token.length() || s.charAt(r.token.length()) == ' ')) return r;
        }
        return null;
    }
}
