package dev.rarityoverlay;

import com.mojang.blaze3d.platform.InputConstants;
import dev.rarityoverlay.screen.ConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class RarityOverlayMod implements ClientModInitializer {
    public static final String MOD_ID = "rarityoverlay";
    private static KeyMapping openKey;

    @Override
    public void onInitializeClient() {
        OverlayConfig.get();   // load (or create) config

        // Hotbar: normally handled by HudMixin (under the item). This HUD element is only a fallback if that mixin cannot apply.
        HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
                Identifier.fromNamespaceAndPath(MOD_ID, "hotbar_rarity"),
                (graphics, deltaTracker) -> OverlayRenderer.drawHotbarFallback(graphics));

        // Settings screen: keybind (default O). Mod Menu is deliberately not required.
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.rarityoverlay.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, category));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.consumeClick()) {
                // Keybinds only fire while no screen is open, so no "screen == null" check is needed (Minecraft#screen was removed in 26.2).
                if (mc.player != null) Compat.setScreen(new ConfigScreen(null));
            }
        });
    }
}
