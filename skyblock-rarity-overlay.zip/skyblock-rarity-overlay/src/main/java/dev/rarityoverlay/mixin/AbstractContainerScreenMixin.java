package dev.rarityoverlay.mixin;

import dev.rarityoverlay.OverlayRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Single, minimal hook: runs for every slot of every container screen (player inventory, chests, ...).
 * Drawing happens before the item so the outline is under it. The pose is already translated to the screen origin,
 * so slot.x / slot.y are the correct coordinates. Doesn't touch clicks, tooltips or hover logic.
 */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {
    @Inject(method = "extractSlot", at = @At("HEAD"))
    private void rarityoverlay$beforeSlot(GuiGraphicsExtractor graphics, Slot slot, int mouseX, int mouseY, CallbackInfo ci) {
        OverlayRenderer.drawSlot(graphics, slot);
    }
}
