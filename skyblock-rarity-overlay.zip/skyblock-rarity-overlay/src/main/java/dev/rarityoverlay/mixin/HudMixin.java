package dev.rarityoverlay.mixin;

import dev.rarityoverlay.OverlayRenderer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 26.2 renamed the HUD class to Hud. Hud#extractSlot draws ONE hotbar item; injecting at HEAD puts our shape under it,
 * exactly like the inventory hook. The full descriptor is spelled out and require = 0 so that, if the signature differs,
 * the mixin skips silently and OverlayRenderer's fallback HUD element takes over instead of crashing the game.
 */
@Mixin(Hud.class)
public abstract class HudMixin {
    @Inject(method = "extractSlot(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IILnet/minecraft/client/DeltaTracker;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;I)V",
            at = @At("HEAD"), require = 0)
    private void rarityoverlay$beforeHotbarItem(GuiGraphicsExtractor graphics, int x, int y, DeltaTracker deltaTracker,
                                                Player player, ItemStack stack, int seed, CallbackInfo ci) {
        OverlayRenderer.drawHotbarSlot(graphics, x, y, stack);
    }
}
