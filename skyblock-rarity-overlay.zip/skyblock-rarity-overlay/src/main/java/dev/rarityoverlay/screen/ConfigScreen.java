package dev.rarityoverlay.screen;

import dev.rarityoverlay.ColorUtil;
import dev.rarityoverlay.Compat;
import dev.rarityoverlay.OverlayConfig;
import dev.rarityoverlay.OverlayRenderer;
import dev.rarityoverlay.Rarity;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.function.Consumer;

/**
 * Settings screen. Left: toggles + appearance. Middle: one row per rarity (select / HEX / reset).
 * Right: visual color picker (SV square + hue bar) for the selected rarity, RGB boxes, live preview grid.
 * All edits mutate the real config immediately, so the live preview AND the real inventory/hotbar update at once.
 * Needs roughly >= 420 x 240 GUI units.
 */
public final class ConfigScreen extends Screen {
    private enum Src { PICKER, HEX, RGB, RESET }

    private static final int SV = 80, CELL = 4, CELLS = SV / CELL;   // picker square: 80x80 px in 4px cells
    private static final int HUE_W = 12;

    private final Screen parent;
    private final OverlayConfig cfg = OverlayConfig.get();
    private final ItemStack sample = new ItemStack(Items.DIAMOND_SWORD);

    private Rarity selected = Rarity.COMMON;
    private float hue, sat, val;
    private boolean syncing;
    private int drag;                         // 0 none, 1 SV square, 2 hue bar

    private final EditBox[] hexBoxes = new EditBox[Rarity.VALUES.length];
    private final Button[] nameButtons = new Button[Rarity.VALUES.length];
    private EditBox rBox, gBox, bBox;
    private Button enabledBtn, invBtn, hotbarBtn, shapeBtn;

    private int colL, colM, colR, svX, svY, hueX;
    private final int[] svCache = new int[CELLS * CELLS];
    private float svCacheHue = -1;

    public ConfigScreen(Screen parent) {
        super(Component.literal("SkyBlock Rarity Overlay"));
        this.parent = parent;
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        colL = Math.max(4, (this.width - 414) / 2);
        colM = colL + 130;
        colR = colL + 300;
        svX = colR; svY = 24; hueX = colR + SV + 6;

        // ---- General + appearance (left column)
        int y = 24;
        enabledBtn = addRenderableWidget(Button.builder(Component.empty(), b -> { cfg.enabled = !cfg.enabled; changed(); refreshToggles(); })
                .bounds(colL, y, 120, 20).build());
        y += 22;
        invBtn = addRenderableWidget(Button.builder(Component.empty(), b -> { cfg.inventory = !cfg.inventory; changed(); refreshToggles(); })
                .bounds(colL, y, 120, 20).build());
        y += 22;
        hotbarBtn = addRenderableWidget(Button.builder(Component.empty(), b -> { cfg.hotbar = !cfg.hotbar; changed(); refreshToggles(); })
                .bounds(colL, y, 120, 20).build());
        y += 22;
        shapeBtn = addRenderableWidget(Button.builder(Component.empty(), b -> {
                    cfg.shape = cfg.shape == OverlayConfig.Shape.CIRCLE ? OverlayConfig.Shape.SQUARE : OverlayConfig.Shape.CIRCLE;
                    changed(); refreshToggles();
                }).bounds(colL, y, 120, 20).build());
        y += 22;
        addRenderableWidget(new Slider(colL, y, 120, "Opacity", 0.1f, 1f, cfg.opacity, false, v -> { cfg.opacity = v; changed(); }));
        y += 22;
        addRenderableWidget(new Slider(colL, y, 120, "Size inset", 0f, 6f, cfg.inset, false, v -> { cfg.inset = v; changed(); }));
        refreshToggles();

        // ---- Rarity rows (middle column)
        for (Rarity r : Rarity.VALUES) {
            int i = r.ordinal(), ry = 24 + i * 21;
            nameButtons[i] = addRenderableWidget(Button.builder(Component.empty(), b -> select(r)).bounds(colM, ry, 74, 18).build());
            EditBox hex = new EditBox(this.font, colM + 76, ry, 50, 18, Component.literal(r.display + " hex"));
            hex.setMaxLength(7);
            hex.setValue(ColorUtil.toHex(cfg.getColor(r)));
            hex.setResponder(s -> onHexTyped(r, hex, s));
            hexBoxes[i] = addRenderableWidget(hex);
            addRenderableWidget(Button.builder(Component.literal("Reset"), b -> resetOne(r)).bounds(colM + 128, ry, 32, 18).build());
            updateNameButton(r);
        }

        // ---- Picker RGB boxes (right column)
        rBox = rgbBox(colR, "R");
        gBox = rgbBox(colR + 38, "G");
        bBox = rgbBox(colR + 76, "B");

        // ---- Bottom row
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(colL, 214, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset All Colors to Defaults"), b -> resetAllColors())
                .bounds(colM, 214, 160, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset All Settings"), b -> confirmResetAll())
                .bounds(colR, 214, 114, 20).build());

        select(selected);
    }

    private EditBox rgbBox(int x, String label) {
        EditBox box = new EditBox(this.font, x, 108, 36, 18, Component.literal(label));
        box.setMaxLength(3);
        box.setHint(Component.literal(label));
        box.setResponder(s -> onRgbTyped(box));
        return addRenderableWidget(box);
    }

    private void refreshToggles() {
        enabledBtn.setMessage(Component.literal("Overlay: " + (cfg.enabled ? "ON" : "OFF")));
        invBtn.setMessage(Component.literal("Inventory: " + (cfg.inventory ? "ON" : "OFF")));
        hotbarBtn.setMessage(Component.literal("Hotbar: " + (cfg.hotbar ? "ON" : "OFF")));
        shapeBtn.setMessage(Component.literal("Shape: " + (cfg.shape == OverlayConfig.Shape.CIRCLE ? "Circular" : "Square")));
    }

    // ------------------------------------------------------------------ color logic

    private void changed() { cfg.touch(); }

    private void select(Rarity r) {
        selected = r;
        float[] hsv = ColorUtil.rgbToHsv(cfg.getColor(r));
        hue = hsv[0]; sat = hsv[1]; val = hsv[2];
        syncRgbBoxes(null);
    }

    /** Single place where a rarity color changes. Updates config, then every widget except the one being typed into. */
    private void applyColor(Rarity r, int rgb, Src src) {
        cfg.setColor(r, rgb);
        syncing = true;
        try {
            updateNameButton(r);
            if (src != Src.HEX) hexBoxes[r.ordinal()].setValue(ColorUtil.toHex(rgb));
            if (r == selected) {
                if (src == Src.HEX || src == Src.RGB || src == Src.RESET) {
                    float[] hsv = ColorUtil.rgbToHsv(rgb);
                    if (hsv[1] > 0 && hsv[2] > 0) hue = hsv[0];   // keep hue stable for greys/black
                    sat = hsv[1]; val = hsv[2];
                }
                if (src != Src.RGB) syncRgbBoxes(null);
            }
        } finally { syncing = false; }
        if (src == Src.RESET || src == Src.HEX || src == Src.RGB) cfg.save();
    }

    private void onHexTyped(Rarity r, EditBox box, String text) {
        if (syncing) return;
        int rgb = ColorUtil.parseHex(text);
        if (rgb < 0) { box.setTextColor(0xFFFF5555); return; }   // invalid: flag it, change nothing
        box.setTextColor(0xFFE0E0E0);
        applyColor(r, rgb, Src.HEX);
    }

    private void onRgbTyped(EditBox box) {
        if (syncing) return;
        int r = ColorUtil.parseChannel(rBox.getValue()), g = ColorUtil.parseChannel(gBox.getValue()), b = ColorUtil.parseChannel(bBox.getValue());
        for (EditBox e : new EditBox[] { rBox, gBox, bBox }) {
            e.setTextColor(ColorUtil.parseChannel(e.getValue()) < 0 ? 0xFFFF5555 : 0xFFE0E0E0);
        }
        if (r < 0 || g < 0 || b < 0) return;                    // incomplete/invalid: wait
        applyColor(selected, (r << 16) | (g << 8) | b, Src.RGB);
    }

    private void syncRgbBoxes(EditBox skip) {
        boolean prev = syncing;
        syncing = true;
        int c = cfg.getColor(selected);
        if (rBox != skip) rBox.setValue(Integer.toString((c >> 16) & 255));
        if (gBox != skip) gBox.setValue(Integer.toString((c >> 8) & 255));
        if (bBox != skip) bBox.setValue(Integer.toString(c & 255));
        for (EditBox e : new EditBox[] { rBox, gBox, bBox }) e.setTextColor(0xFFE0E0E0);
        syncing = prev;
    }

    private void updateNameButton(Rarity r) {
        int rgb = cfg.getColor(r);
        nameButtons[r.ordinal()].setMessage(Component.literal(r.display).withStyle(s -> s.withColor(rgb)));
    }

    private void resetOne(Rarity r) {            // touches ONLY this rarity
        cfg.resetColor(r);
        applyColor(r, cfg.getColor(r), Src.RESET);
        hexBoxes[r.ordinal()].setTextColor(0xFFE0E0E0);
    }

    private void resetAllColors() {              // colors only; shape/thickness/opacity/inset untouched
        cfg.resetAllColors();
        for (Rarity r : Rarity.VALUES) {
            applyColor(r, cfg.getColor(r), Src.RESET);
            hexBoxes[r.ordinal()].setTextColor(0xFFE0E0E0);
        }
        select(selected);
    }

    private void confirmResetAll() {
        Compat.setScreen(new ConfirmScreen(yes -> {
            if (yes) { cfg.resetAll(); cfg.save(); }
            Compat.setScreen(new ConfigScreen(parent));      // rebuild so every widget shows the new values
        }, Component.literal("Reset All Settings?"),
           Component.literal("This restores shape, thickness, opacity, inset, toggles and ALL colors to their defaults.")));
    }

    // ------------------------------------------------------------------ picker input

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean doubleClick) {
        double mx = ev.x(), my = ev.y();
        if (mx >= svX && mx < svX + SV && my >= svY && my < svY + SV) { drag = 1; pick(mx, my); return true; }
        if (mx >= hueX && mx < hueX + HUE_W && my >= svY && my < svY + SV) { drag = 2; pick(mx, my); return true; }
        return super.mouseClicked(ev, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent ev, double dx, double dy) {
        if (drag != 0) { pick(ev.x(), ev.y()); return true; }
        return super.mouseDragged(ev, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent ev) {
        if (drag != 0) { drag = 0; cfg.save(); return true; }
        return super.mouseReleased(ev);
    }

    private void pick(double mx, double my) {
        if (drag == 1) {
            sat = (float) Math.max(0, Math.min(1, (mx - svX) / SV));
            val = 1f - (float) Math.max(0, Math.min(1, (my - svY) / SV));
        } else {
            hue = (float) Math.max(0, Math.min(0.9999, (my - svY) / SV));
        }
        applyColor(selected, ColorUtil.hsvToRgb(hue, sat, val), Src.PICKER);
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        g.centeredText(this.font, this.title, this.width / 2, 8, 0xFFFFFFFF);

        // section labels
        g.text(this.font, Component.literal("General / Appearance"), colL, 13, 0xFFAAAAAA);
        g.text(this.font, Component.literal("Rarity Colors"), colM, 13, 0xFFAAAAAA);
        g.text(this.font, Component.literal("Picker: " + selected.display), colR, 13, 0xFFAAAAAA);

        // marker for the selected rarity row
        int sy = 24 + selected.ordinal() * 21;
        g.fill(colM - 4, sy, colM - 2, sy + 18, 0xFFFFFFFF);

        drawPicker(g);
        drawPreview(g);
    }

    private void drawPicker(GuiGraphicsExtractor g) {
        if (svCacheHue != hue) {
            svCacheHue = hue;
            for (int cy = 0; cy < CELLS; cy++)
                for (int cx = 0; cx < CELLS; cx++)
                    svCache[cy * CELLS + cx] = 0xFF000000 | ColorUtil.hsvToRgb(hue, (cx + 0.5f) / CELLS, 1f - (cy + 0.5f) / CELLS);
        }
        g.fill(svX - 1, svY - 1, svX + SV + 1, svY + SV + 1, 0xFF000000);
        g.fill(hueX - 1, svY - 1, hueX + HUE_W + 1, svY + SV + 1, 0xFF000000);
        for (int cy = 0; cy < CELLS; cy++)
            for (int cx = 0; cx < CELLS; cx++)
                g.fill(svX + cx * CELL, svY + cy * CELL, svX + (cx + 1) * CELL, svY + (cy + 1) * CELL, svCache[cy * CELLS + cx]);
        for (int i = 0; i < CELLS; i++)
            g.fill(hueX, svY + i * CELL, hueX + HUE_W, svY + (i + 1) * CELL, 0xFF000000 | ColorUtil.hsvToRgb((i + 0.5f) / CELLS, 1f, 1f));

        // markers
        int mx = svX + Math.round(sat * SV), my = svY + Math.round((1 - val) * SV);
        g.fill(mx - 3, my - 3, mx + 3, my - 2, 0xFFFFFFFF);
        g.fill(mx - 3, my + 2, mx + 3, my + 3, 0xFFFFFFFF);
        g.fill(mx - 3, my - 3, mx - 2, my + 3, 0xFFFFFFFF);
        g.fill(mx + 2, my - 3, mx + 3, my + 3, 0xFFFFFFFF);
        int hy = svY + Math.round(hue * SV);
        g.fill(hueX - 2, hy - 1, hueX + HUE_W + 2, hy + 1, 0xFFFFFFFF);

        // current color swatch
        g.fill(colR, 130, colR + 114, 138, 0xFF000000 | cfg.getColor(selected));
    }

    /** Live preview: all nine rarities at true size on slot-gray, drawn with the SAME renderer as the real GUI. */
    private void drawPreview(GuiGraphicsExtractor g) {
        g.text(this.font, Component.literal("Live preview (always shown)"), colR, 142, 0xFFAAAAAA);
        for (Rarity r : Rarity.VALUES) {
            int i = r.ordinal(), cx = colR + (i % 5) * 20, cy = 154 + (i / 5) * 20;
            if (r == selected) g.fill(cx - 1, cy - 1, cx + 19, cy + 19, 0xFFFFFFFF);
            g.fill(cx, cy, cx + 18, cy + 18, 0xFF8B8B8B);
            OverlayRenderer.draw(g, cx + 1, cy + 1, r, false);   // filled shape (under item)
            g.item(sample, cx + 1, cy + 1);
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void removed() { cfg.save(); }

    @Override
    public void onClose() { cfg.save(); Compat.setScreen(parent); }

    // ------------------------------------------------------------------ slider

    private static final class Slider extends AbstractSliderButton {
        private final String label;
        private final float min, max;
        private final boolean integer;
        private final Consumer<Float> setter;

        Slider(int x, int y, int w, String label, float min, float max, float current, boolean integer, Consumer<Float> setter) {
            super(x, y, w, 20, Component.empty(), (current - min) / (max - min));
            this.label = label; this.min = min; this.max = max; this.integer = integer; this.setter = setter;
            updateMessage();
        }

        private float actual() {
            float v = min + (float) this.value * (max - min);
            return integer ? Math.round(v) : v;
        }

        @Override protected void updateMessage() {
            float v = actual();
            setMessage(Component.literal(label + ": " + (integer ? Integer.toString((int) v) : String.format("%.2f", v))));
        }

        @Override protected void applyValue() {
            if (integer) this.value = (actual() - min) / (max - min);   // snap handle to whole steps
            setter.accept(actual());
        }
    }
}
